#!/usr/bin/env bash
sudo amazon-linux-extras install epel -y
