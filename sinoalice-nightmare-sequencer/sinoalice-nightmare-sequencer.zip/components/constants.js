export const SUCCESS = 'SUCCESS';
export const ERROR = 'ERROR';
export const NORMAL_COLO_TIME_MINS = 20;
export const SPECIAL_COLO_TIME_MINS = 40;