#!/usr/bin/env bash
sudo yum install -y chromium